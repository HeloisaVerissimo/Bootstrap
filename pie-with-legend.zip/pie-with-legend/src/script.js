// Build the chart
Highcharts.chart("container", {
  chart: {
    plotBackgroundColor: null,
    plotBorderWidth: null,
    plotShadow: false,
    type: "pie"
  },
  title: {
    text: "Sistemas mais usados de gerenciamento de estoque"
  },
  tooltip: {
    pointFormat: "{series.name}: <b>{point.percentage:.1f}%</b>"
  },
  accessibility: {
    point: {
      valueSuffix: "%"
    }
  },
  plotOptions: {
    pie: {
      allowPointSelect: true,
      cursor: "pointer",
      dataLabels: {
        enabled: false
      },
      showInLegend: true
    }
  },
  series: [
    {
      name: "Sistemas",
      colorByPoint: true,
      data: [
        {
          name: "Sys Market",
          y: 52.41,
          sliced: true,
          selected: true
        },
        {
          name: "Tasy",
          y: 11.84
        },
        {
          name: "Excel",
          y: 10.85
        },
        {
          name: "SAP",
          y: 4.67
        },
        {
          name: "Protheus",
          y: 4.18
        },
        {
          name: "Outros",
          y: 7.05
        }
      ]
    }
  ]
});
